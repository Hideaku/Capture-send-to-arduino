import serial
import cv2
import numpy as np
import threading
import mss
import time
from pynput import keyboard

ser = serial.Serial('COM4', 115200, timeout=1)
ser.flush()
screenshot_enabled = False
screenshot_counter = 0

def capture_and_send():
    global screenshot_enabled, screenshot_counter
    with mss.mss() as sct:
        monitor = sct.monitors[1]  # Capture the entire screen
        while True:
            start_time = time.time()
            try:
                # Capture the screen
                screen = sct.grab(monitor)
                screen_np = np.array(screen)[:, :, :3]
                screen_np = cv2.cvtColor(screen_np, cv2.COLOR_BGR2GRAY)

                # Resize to 128x64 with cubic interpolation
                screen_np = cv2.resize(screen_np, (128, 64), interpolation=cv2.INTER_CUBIC)

                # Apply adaptive thresholding
                adaptive_thresh = cv2.adaptiveThreshold(screen_np, 255,
                                                         cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                                         cv2.THRESH_BINARY, 11, 2)

                # Convert image to byte array
                pixels = adaptive_thresh.flatten()
                byte_array = bytearray()
                byte_array.append(0xA5)

                for i in range(0, len(pixels), 8):
                    byte = 0
                    for bit in range(8):
                        if i + bit < len(pixels) and pixels[i + bit] == 0:
                            byte |= (1 << bit)
                    byte_array.append(byte)

                byte_array.append(0x5A)

                # Send data to Arduino
                ser.write(byte_array)
                response = ser.read()
                if response:
                    print(f"Received response: {response}")

                # Take a screenshot if enabled
                if screenshot_enabled:
                    filename = f"screenshot_{screenshot_counter}.png"
                    cv2.imwrite(filename, screen_np)
                    print(f"Saved screenshot: {filename}")
                    screenshot_counter += 1
                    screenshot_enabled = False  # Disable after one screenshot

            except Exception as e:
                print(f"Error during capture and send: {e}")

            end_time = time.time()
            elapsed_time = end_time - start_time
            print(f"Frame captured and sent in {elapsed_time:.4f} seconds")

            # Sleep to maintain a consistent frame rate
            if elapsed_time < 0.02:
                time.sleep(0.02 - elapsed_time)

def on_press(key):
    global screenshot_enabled
    try:
        if key.char == '*':  # Check if '*' key is pressed
            screenshot_enabled = True
            print("Screenshot enabled")
    except AttributeError:
        pass  # Ignore other key presses

# Start screen capture thread
thread = threading.Thread(target=capture_and_send, daemon=True)
thread.start()

# Set up keyboard listener
with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
