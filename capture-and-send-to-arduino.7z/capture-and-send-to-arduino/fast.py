import serial
from PIL import ImageGrab, Image

# Set the serial port (replace 'COM4' with your port)
ser = serial.Serial('COM4', 115200)  # Increase baud rate
ser.flush()

# Define the resolution for the OLED display
WIDTH = 128
HEIGHT = 64

def capture_and_send():
    # Capture the entire screen
    screen = ImageGrab.grab()
    
    # Resize the image to match the OLED display resolution
    screen = screen.resize((WIDTH, HEIGHT), Image.LANCZOS)
    screen = screen.convert('1')  # Convert to black and white image

    # Convert the image to a byte array
    pixels = list(screen.getdata())
    byte_array = bytearray()
    byte_array.append(0xA5)  # Start of data packet

    for i in range(0, len(pixels), 8):
        byte = 0
        for bit in range(8):
            if i + bit < len(pixels) and pixels[i + bit] == 0:
                byte |= (1 << bit)
        byte_array.append(byte)

    byte_array.append(0x5A)  # End of data packet

    # Send the data to Arduino
    ser.write(byte_array)

while True:
    capture_and_send()
